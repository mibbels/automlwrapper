from .sklearn_wrapper import CAAFEClassifier
from .image_wrapper import CAAFEImageClassifier
from .segmentation_wrapper import CAAFEImageSegmentor
from .coco_wrapper import CAAFEImageCOCO